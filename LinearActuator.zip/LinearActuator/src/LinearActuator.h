
class LinearActuator
 {
  public:
  LinearActuator(){};
  void init(int Fwd_Pin, int Rev_Pin, int En_Pin, int Pot_Pin);
  void set_state(bool state);
  void set_limits(int Lower_Limit, int Upper_Limit);
  void set_end_limit_threshold(float end_threshold_value);
  int limits(int Speed);
  int get_raw_pos();
  float get_pos();
  void move_actuator(int Speed); 
  
  void set_alpha(float a);
  int ema();

  int FwdPin,RevPin,EnPin,PotPin;
  int LowerLimit =    0;
  int UpperLimit = 4095;
  float end_threshold;
  float alpha = 0.1;
  int filteredvalue = 0;
  
 };
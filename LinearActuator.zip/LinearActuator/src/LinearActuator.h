
class LinearActuator
 {
  public:
  LinearActuator(){};
  void init(int Fwd_Pin, int Rev_Pin, int Pot_Pin);
  void set_stoke_length(float Stroke_Length);
  void set_limits(int Lower_Limit, int Upper_Limit);
  void move_actuator(int Speed); 
  void calibrate();
  float get_pos();
  int get_raw_pos();

  int FwdPin,RevPin,PotPin;
  float StrokeLength;
  int UpperLimit = 4095;
  int LowerLimit =    0;
 };
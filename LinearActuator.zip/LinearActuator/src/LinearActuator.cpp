#include<Arduino.h>
#include "LinearActuator.h"

void LinearActuator::init(int Fwd_Pin, int Rev_Pin, int Pot_Pin)
 {
  FwdPin = Fwd_Pin;
  RevPin = Rev_Pin;
  PotPin = Pot_Pin;
  pinMode(FwdPin, OUTPUT);
  pinMode(RevPin, OUTPUT);
 }
void LinearActuator::set_limits(int Lower_Limit , int Upper_Limit)
 {
  LowerLimit = Lower_Limit;
  UpperLimit = Upper_Limit;
 }
void LinearActuator::set_stoke_length(float Stroke_Length) // to assign stroke length.
 {
  StrokeLength = Stroke_Length;
 }
void LinearActuator::move_actuator(int Speed) // takes in speed ranging from  -100 to 100.
 {
  if(Speed>0 && Speed<=100)
   {
    analogWrite(RevPin, 0);
    analogWrite(FwdPin, map(Speed, 0, 100, 0, 255));
   }
  else if(Speed<0 && Speed>=-100)
   {
    analogWrite(FwdPin, 0);
    analogWrite(RevPin, map(Speed, 0, -100, 0, 255));
   }
  else
   {
    analogWrite(FwdPin, 0);
    analogWrite(RevPin, 0);
   }
 }


float LinearActuator::get_pos()   // returns stroke length position value.
 {
  return map(analogRead(PotPin), LowerLimit, UpperLimit, 0, 10000)*StrokeLength/10000; // returns mapped length value. (works after calibrations is done and the stroke length is defined).
 }

int LinearActuator::get_raw_pos() // returns raw analog input value from potentiometer.
 {
  return analogRead(PotPin);
 }



void LinearActuator::calibrate() // Calibration done by extending to its Max length and records its position , then rectracts to its Min length and records its position.
 {
  int max_limit=0,min_limit=4095;
  move_actuator(100);
  while(true)
   {
    if(get_raw_pos()>1.01*max_limit)
     {
      delay(1000);
     }
    else
     {
      max_limit = get_raw_pos();
      break;
     }
   }
  Serial.print("Linear actuator upper limit: ");Serial.println(max_limit);
  delay(500);
  move_actuator(-100);
  while(true)
   {
    if(get_raw_pos()<1.01*min_limit)
     {
      delay(1000);
     }
    else
     {
      min_limit = get_raw_pos();
      break;
     }
   }
  Serial.print("Linear actuator lower limit: ");Serial.println(min_limit);
 } 

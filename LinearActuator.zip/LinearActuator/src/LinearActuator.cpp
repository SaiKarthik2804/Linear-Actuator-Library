#include<Arduino.h>
#include "LinearActuator.h"

void LinearActuator::init(int Fwd_Pin, int Rev_Pin,int En_Pin, int Pot_Pin)
 {
  FwdPin = Fwd_Pin;     // Assigning Forward Pin
  RevPin = Rev_Pin;     // Assigning Reverse Pin
  EnPin  = En_Pin;      // Assigning Enable Pin
  PotPin = Pot_Pin;     // Assigning Potentiometer Pin for feedback
  pinMode(FwdPin, OUTPUT);
  pinMode(RevPin, OUTPUT);
  pinMode( EnPin, OUTPUT);
 }

void LinearActuator::set_state(bool state)
 {
  digitalWrite(EnPin, state);
 }

void LinearActuator::set_limits(int Lower_Limit , int Upper_Limit)
 {
  LowerLimit = constrain(Lower_Limit,0,4095);
  UpperLimit = constrain(Upper_Limit,0,4095);
 }

void LinearActuator::set_end_limit_threshold(float end_threshold_value)
 {
  end_threshold = constrain(end_threshold_value, 0, 100);
 }

int LinearActuator::limits(int Speed)
 {
  if (ema() > UpperLimit) 
   {
    int distanceToMax = UpperLimit - ema();
    Speed = map(distanceToMax, 0, end_threshold, 0, Speed);
   }
  else if (ema() < LowerLimit) 
   {
    int distanceToMin = ema() - LowerLimit;
    Speed = map(distanceToMin, 0, end_threshold, 0, Speed);
   }
  return Speed;

 }

int LinearActuator::get_raw_pos() // returns raw analog input value from potentiometer.
 {
  return analogRead(PotPin);
 }

float LinearActuator::get_pos()   // returns stroke length as Percentage.
 {
  return map(get_raw_pos(), LowerLimit, UpperLimit, 0, 10000)/100; // returns mapped length value as %. (works after calibrations is done)
 }

void LinearActuator::set_alpha(float a) // returns raw analog input value from potentiometer.
 {
  alpha = constrain(a,0,1);
 }

int LinearActuator::ema()         // returns raw analog input value from potentiometer.
 {
  filteredvalue = alpha * get_raw_pos() + (1 - alpha) * filteredvalue;
  return int(filteredvalue);
 }


void LinearActuator::move_actuator(int Speed) // takes in speed ranging from  -100 to 100.
 {
  Speed=limits(Speed);
  if(Speed>0 && Speed<=100)
   {
    analogWrite(FwdPin, map(Speed, 0, 100, 0, 255));
    analogWrite(RevPin, 0);
   }
  else if(Speed<0 && Speed>=-100)
   {
    analogWrite(FwdPin, 0);
    analogWrite(RevPin, map(Speed, 0, -100, 0, 255));
   }
  else
   {
    analogWrite(FwdPin, 0);
    analogWrite(RevPin, 0);
   }
 }
